# Fylz archive fixture

Five files in two directories, one nested.
